<?php
    return [
        'meta'          => [
            'name'         => "UKWapp WhatsApp Bildirim Entegrasyonu",
            'descriptions' => 'UKWapp ile Müşterilerinize WhatsApp üzerinden Bildirim Gönderin!',
        ],
        'success1'      => "Ayarlar Başarıyla Kaydedildi",

        'error1'        => "Bir Hata Oluştu",
    ];