<?php
    return [
        'meta'          => [
            'name'         => "UKWapp WhatsApp Notification Integration",
            'descriptions' => 'Send Notifications to Your Customers via WhatsApp with UKWapp!',
        ],
        'success1'      => 'Settings Saved Successfully',

        'error1'        => 'Something went wrong',
    ];